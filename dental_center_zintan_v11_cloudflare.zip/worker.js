const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };
const COOKIE = "dc_session";

function json(data, status=200, extra={}) {
  return new Response(JSON.stringify(data), {status, headers:{...JSON_HEADERS, ...extra}});
}
function html(data, status=200) {
  return new Response(data,{status,headers:{"content-type":"text/html; charset=utf-8"}});
}
function hex(bytes){return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,"0")).join("");}
function bytesToB64(bytes){let s=""; for(const b of bytes)s+=String.fromCharCode(b); return btoa(s).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");}
function b64ToBytes(s){s=s.replaceAll("-","+").replaceAll("_","/"); while(s.length%4)s+="="; const bin=atob(s); return Uint8Array.from(bin,c=>c.charCodeAt(0));}
async function sha256(text){return hex(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text)));}
async function pbkdf2(password,saltB64,iterations=120000){
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:b64ToBytes(saltB64),iterations,hash:"SHA-256"},key,256);
  return hex(bits);
}
async function makePassword(password){
  const salt=bytesToB64(crypto.getRandomValues(new Uint8Array(16)));
  const iterations=120000;
  const hash=await pbkdf2(password,salt,iterations);
  return {salt,iterations,hash};
}
function cookies(req){
  const out={}; for(const p of (req.headers.get("Cookie")||"").split(";")){const i=p.indexOf("=");if(i>0)out[p.slice(0,i).trim()]=p.slice(i+1).trim();}
  return out;
}
function setCookie(token,maxAge){
  return `${COOKIE}=${token}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Strict`;
}
function clearCookie(){return `${COOKIE}=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Strict`;}
function randomToken(){return bytesToB64(crypto.getRandomValues(new Uint8Array(32)));}

async function session(req,env){
  const token=cookies(req)[COOKIE]; if(!token)return null;
  const hash=await sha256(token);
  const row=await env.DB.prepare(`SELECT s.*,u.username,u.role,u.active FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash,Math.floor(Date.now()/1000)).first();
  return row||null;
}
async function requireAuth(req,env){
  const s=await session(req,env);
  if(!s)return json({error:"غير مصرح"},401);
  if(req.method!=="GET" && req.method!=="HEAD"){
    const csrf=req.headers.get("X-CSRF-Token");
    if(!csrf || csrf!==s.csrf_token)return json({error:"رمز حماية غير صالح"},403);
  }
  return s;
}
function route(path,method){
  return `${method} ${path}`;
}

async function api(req,env,url){
  const path=url.pathname, method=req.method;
  if(path==="/api/health" && method==="GET") return json({ok:true,service:"dental-center-zintan",time:new Date().toISOString()});

  if(path==="/api/auth/setup" && method==="POST"){
    const body=await req.json().catch(()=>({}));
    if(!env.SETUP_CODE_SHA256)return json({error:"إعداد SETUP_CODE_SHA256 مفقود"},500);
    const supplied=String(body.setup_code||"");
    if(await sha256(supplied)!==env.SETUP_CODE_SHA256)return json({error:"رمز الإعداد غير صحيح"},403);
    const existing=await env.DB.prepare("SELECT COUNT(*) c FROM users").first();
    if(Number(existing?.c||0)>0)return json({error:"تم إنشاء الحساب مسبقاً"},409);
    const username=String(body.username||"admin").trim().slice(0,50);
    const password=String(body.password||"");
    if(password.length<10)return json({error:"كلمة المرور يجب ألا تقل عن 10 أحرف"},400);
    const p=await makePassword(password);
    await env.DB.prepare("INSERT INTO users(username,password_hash,salt,iterations,role) VALUES(?,?,?,?,?)").bind(username,p.hash,p.salt,p.iterations,"admin").run();
    return json({ok:true,message:"تم إنشاء حساب المدير. يمكنك تسجيل الدخول."});
  }

  if(path==="/api/auth/login" && method==="POST"){
    const body=await req.json().catch(()=>({}));
    const username=String(body.username||"").trim();
    const password=String(body.password||"");
    const u=await env.DB.prepare("SELECT * FROM users WHERE username=? AND active=1").bind(username).first();
    if(!u)return json({error:"اسم المستخدم أو كلمة المرور غير صحيحة"},401);
    const hash=await pbkdf2(password,u.salt,Number(u.iterations||120000));
    if(hash!==u.password_hash)return json({error:"اسم المستخدم أو كلمة المرور غير صحيحة"},401);
    const token=randomToken(), tokenHash=await sha256(token), csrf=randomToken();
    const ttl=Number(env.SESSION_TTL_SECONDS||28800), exp=Math.floor(Date.now()/1000)+ttl;
    await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,csrf_token,expires_at) VALUES(?,?,?,?)").bind(tokenHash,u.id,csrf,exp).run();
    return json({ok:true,user:{username:u.username,role:u.role},csrf_token:csrf},{headers:{"content-type":"application/json; charset=utf-8","Set-Cookie":setCookie(token,ttl)}});
  }

  if(path==="/api/auth/logout" && method==="POST"){
    const s=await session(req,env); if(s){const token=cookies(req)[COOKIE]; await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();}
    return json({ok:true},{headers:{"content-type":"application/json; charset=utf-8","Set-Cookie":clearCookie()}});
  }

  if(path==="/api/auth/me" && method==="GET"){
    const s=await session(req,env); return json(s?{authenticated:true,user:{username:s.username,role:s.role},csrf_token:s.csrf_token}:{authenticated:false});
  }

  if(path==="/api/services" && method==="GET"){
    return json((await env.DB.prepare("SELECT id,title,description FROM services WHERE active=1 ORDER BY sort_order,id").all()).results);
  }
  if(path==="/api/doctors" && method==="GET"){
    return json((await env.DB.prepare("SELECT id,name,specialty FROM doctors WHERE active=1 ORDER BY specialty,name").all()).results);
  }
  if(path==="/api/news" && method==="GET"){
    return json((await env.DB.prepare("SELECT id,title,body,created_at FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 10").all()).results);
  }
  if(path==="/api/statistics" && method==="GET"){
    return json((await env.DB.prepare("SELECT * FROM statistics ORDER BY stat_year DESC").all()).results);
  }
  if(path.startsWith("/api/doctor-schedule/") && method==="GET"){
    const id=Number(path.split("/").pop());
    return json((await env.DB.prepare("SELECT weekday,start_time,end_time FROM schedules WHERE doctor_id=? ORDER BY weekday,start_time").bind(id).all()).results);
  }
  if(path==="/api/availability" && method==="GET"){
    const date=url.searchParams.get("date")||"";
    const doctorId=Number(url.searchParams.get("doctor_id")||0);
    if(!date||!doctorId)return json({error:"التاريخ والطبيب مطلوبان"},400);
    const rows=(await env.DB.prepare("SELECT appointment_time FROM bookings WHERE doctor_id=? AND appointment_date=? AND status IN ('new','confirmed')").bind(doctorId,date).all()).results;
    return json(rows.map(x=>x.appointment_time));
  }
  if(path==="/api/bookings" && method==="POST"){
    const b=await req.json().catch(()=>({}));
    const patient=String(b.patient_name||"").trim(), phone=String(b.phone||"").trim();
    const date=String(b.appointment_date||""), time=String(b.appointment_time||"");
    const doctor=Number(b.doctor_id||0), service=Number(b.service_id||0)||null;
    if(patient.length<2||phone.length<5||!date||!time||!doctor)return json({error:"يرجى إكمال بيانات الحجز"},400);
    const day=new Date(date+"T12:00:00Z").getUTCDay();
    const sch=await env.DB.prepare("SELECT 1 FROM schedules WHERE doctor_id=? AND weekday=? AND start_time<=? AND end_time>?").bind(doctor,day,time,time).first();
    if(!sch)return json({error:"الطبيب غير متاح في هذا اليوم أو الوقت"},400);
    const conflict=await env.DB.prepare("SELECT id FROM bookings WHERE doctor_id=? AND appointment_date=? AND appointment_time=? AND status IN ('new','confirmed')").bind(doctor,date,time).first();
    if(conflict)return json({error:"هذا الموعد محجوز بالفعل، اختر موعداً آخر"},409);
    const num="ZTN-"+new Date().toISOString().slice(0,10).replaceAll("-","")+"-"+crypto.randomUUID().slice(0,8).toUpperCase();
    try{
      await env.DB.prepare("INSERT INTO bookings(booking_number,patient_name,phone,service_id,doctor_id,appointment_date,appointment_time,status,notes) VALUES(?,?,?,?,?,?,?,?,?)")
        .bind(num,patient,phone,service,doctor,date,time,"new",String(b.notes||"").slice(0,500)).run();
      return json({ok:true,booking_number:num});
    }catch(e){return json({error:"تعذر حفظ الحجز، حاول مرة أخرى"},500);}
  }

  // Admin
  const s=await requireAuth(req,env); if(s instanceof Response)return s;

  if(path==="/api/admin/bookings" && method==="GET"){
    return json((await env.DB.prepare(`SELECT b.*,d.name doctor_name,s.title service_title FROM bookings b LEFT JOIN doctors d ON d.id=b.doctor_id LEFT JOIN services s ON s.id=b.service_id ORDER BY b.appointment_date DESC,b.appointment_time DESC LIMIT 300`).all()).results);
  }
  if(path.startsWith("/api/admin/bookings/") && method==="PATCH"){
    const id=Number(path.split("/").pop()), b=await req.json().catch(()=>({}));
    const status=String(b.status||"");
    if(!["new","confirmed","completed","cancelled"].includes(status))return json({error:"حالة غير صحيحة"},400);
    await env.DB.prepare("UPDATE bookings SET status=? WHERE id=?").bind(status,id).run();
    return json({ok:true});
  }
  if(path==="/api/admin/services" && method==="GET") return json((await env.DB.prepare("SELECT * FROM services ORDER BY sort_order,id").all()).results);
  if(path==="/api/admin/services" && method==="POST"){
    const b=await req.json(); await env.DB.prepare("INSERT INTO services(title,description,sort_order) VALUES(?,?,?)").bind(String(b.title||""),String(b.description||""),Number(b.sort_order||0)).run(); return json({ok:true});
  }
  if(path.startsWith("/api/admin/services/") && method==="PUT"){
    const id=Number(path.split("/").pop()), b=await req.json(); await env.DB.prepare("UPDATE services SET title=?,description=?,active=?,sort_order=? WHERE id=?").bind(String(b.title||""),String(b.description||""),b.active?1:0,Number(b.sort_order||0),id).run(); return json({ok:true});
  }
  if(path==="/api/admin/announcements" && method==="GET") return json((await env.DB.prepare("SELECT * FROM announcements ORDER BY id DESC").all()).results);
  if(path==="/api/admin/announcements" && method==="POST"){
    const b=await req.json(); await env.DB.prepare("INSERT INTO announcements(title,body,active) VALUES(?,?,1)").bind(String(b.title||""),String(b.body||"")).run(); return json({ok:true});
  }
  if(path==="/api/admin/stats" && method==="GET") return json((await env.DB.prepare("SELECT * FROM statistics ORDER BY stat_year DESC").all()).results);
  if(path==="/api/admin/stats" && method==="PUT"){
    const b=await req.json(); await env.DB.prepare(`INSERT INTO statistics(stat_year,root_canal,conservative,periodontal,extractions,opg) VALUES(?,?,?,?,?,?) ON CONFLICT(stat_year) DO UPDATE SET root_canal=excluded.root_canal,conservative=excluded.conservative,periodontal=excluded.periodontal,extractions=excluded.extractions,opg=excluded.opg`).bind(Number(b.stat_year),Number(b.root_canal||0),Number(b.conservative||0),Number(b.periodontal||0),Number(b.extractions||0),Number(b.opg||0)).run(); return json({ok:true});
  }
  if(path==="/api/admin/doctors" && method==="GET") return json((await env.DB.prepare("SELECT * FROM doctors ORDER BY specialty,name").all()).results);
  if(path==="/api/admin/doctors" && method==="POST"){
    const b=await req.json(); await env.DB.prepare("INSERT INTO doctors(name,specialty,active) VALUES(?,?,1)").bind(String(b.name||""),String(b.specialty||"طب أسنان")).run(); return json({ok:true});
  }
  if(path.startsWith("/api/admin/schedules/") && method==="GET"){
    const id=Number(path.split("/").pop()); return json((await env.DB.prepare("SELECT * FROM schedules WHERE doctor_id=? ORDER BY weekday,start_time").bind(id).all()).results);
  }
  if(path==="/api/admin/schedules" && method==="POST"){
    const b=await req.json(); await env.DB.prepare("INSERT INTO schedules(doctor_id,weekday,start_time,end_time) VALUES(?,?,?,?)").bind(Number(b.doctor_id),Number(b.weekday),String(b.start_time),String(b.end_time)).run(); return json({ok:true});
  }
  if(path.startsWith("/api/admin/schedules/") && method==="DELETE"){
    const id=Number(path.split("/").pop()); await env.DB.prepare("DELETE FROM schedules WHERE id=?").bind(id).run(); return json({ok:true});
  }
  if(path==="/api/admin/today" && method==="GET"){
    const today=new Date().toISOString().slice(0,10); return json((await env.DB.prepare("SELECT b.*,d.name doctor_name,s.title service_title FROM bookings b LEFT JOIN doctors d ON d.id=b.doctor_id LEFT JOIN services s ON s.id=b.service_id WHERE appointment_date=? ORDER BY appointment_time").bind(today).all()).results);
  }
  return json({error:"المسار غير موجود"},404);
}

export default {
 async fetch(req,env){
   const url=new URL(req.url);
   try{
     if(url.pathname.startsWith("/api/")) return await api(req,env,url);
     if(url.pathname==="/admin"||url.pathname==="/admin/") return env.ASSETS.fetch(new Request(new URL("/admin.html",url),req));
     return env.ASSETS.fetch(req);
   }catch(e){
     return json({error:"حدث خطأ داخلي",detail:env.NODE_ENV==="development"?String(e):undefined},500);
   }
 }
};
