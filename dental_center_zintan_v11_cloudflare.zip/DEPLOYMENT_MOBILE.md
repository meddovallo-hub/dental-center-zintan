# نشر V11 — دليل مختصر للهاتف

## 1) GitHub
ارفع كل ملفات هذه الحزمة إلى مستودع GitHub خاص (Private).

## 2) Cloudflare
Workers & Pages → Create application → Worker.
اربط مستودع GitHub.

## 3) D1
Workers & Pages → D1 → Create database.
الاسم: dental-center-zintan
انسخ Database ID وضعه في wrangler.toml.

## 4) Migration
من Cloudflare/واجهة Wrangler نفّذ migrations بالترتيب:
0001_initial.sql
0002_seed.sql

## 5) Secret
لا تنشر SETUP_CODE.txt. قيمة SETUP_CODE_SHA256 الموجودة في wrangler.toml ليست كلمة المرور نفسها.

## 6) أول دخول
افتح:
https://اسم-المشروع.workers.dev/setup.html
ثم أنشئ حساب admin.
بعدها:
https://اسم-المشروع.workers.dev/admin

## 7) الرابط العام
الرابط الافتراضي من Cloudflare مجاني. الدومين الخاص يحتاج أن يكون لديك دومين تملكه.
